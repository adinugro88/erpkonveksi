<?php $__env->startSection('Judul', 'Detail Surat Jalan'); ?>
<?php $__env->startSection('action', $suratJalan->kode_sj); ?>

<div class="container pb-5">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center bg-white border-bottom-0">
            <h5 class="mb-0">Informasi Surat Jalan</h5>
            <div>
                <a href="<?php echo e(route('surat-jalan.preview', $suratJalan->id)); ?>" target="_blank" class="btn btn-info mb-3">
                    <i class="fas fa-file-pdf"></i> Download / Print PDF
                </a>
               
                 
                <a href="<?php echo e(route('surat-jalan.form', $suratJalan->id)); ?>" class="btn btn-warning mb-3 ml-3">
                                        <i class="fas fa-edit"></i>
                                    </a>
                <a href="<?php echo e(route('surat-jalan.index')); ?>" class="btn btn-secondary mb-3 ml-3">Kembali</a>
            </div>
        </div>
        <div class="card-body">
            <div class="row mb-4">
                <div class="col-md-6">
                    <table class="table table-borderless">
                        <tr>
                            <td width="150" class="font-weight-bold">Kode SJ</td>
                            <td>: <?php echo e($suratJalan->kode_sj); ?></td>
                        </tr>
                        <tr>
                            <td class="font-weight-bold">Tanggal</td>
                            <td>: <?php echo e(\Carbon\Carbon::parse($suratJalan->tanggal)->format('d F Y')); ?></td>
                        </tr>
                        <tr>
                            <td class="font-weight-bold">Jenis</td>
                            <td>
                                : <span class="badge badge-<?php echo e($suratJalan->jenis == 'keluar' ? 'warning' : 'success'); ?>">
                                    <?php echo e(strtoupper($suratJalan->jenis)); ?>

                                  </span>
                            </td>
                        </tr>
                        <tr>
                            <td class="font-weight-bold">Job / Project</td>
                            <td>: <?php echo e($suratJalan->jobCust->nama ?? '-'); ?></td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <table class="table table-borderless">
                        <tr>
                            <td width="150" class="font-weight-bold">Pengirim</td>
                            <td>: <?php echo e($suratJalan->pengirim ?? '-'); ?></td>
                        </tr>
                        <tr>
                            <td class="font-weight-bold">Penerima</td>
                            <td>: <?php echo e($suratJalan->penerima ?? '-'); ?></td>
                        </tr>
                        <tr>
                            <td class="font-weight-bold">Sopir</td>
                            <td>: <?php echo e($suratJalan->sopir ?? '-'); ?></td>
                        </tr>
                        <tr>
                            <td class="font-weight-bold">No. Kendaraan</td>
                            <td>: <?php echo e($suratJalan->no_kendaraan ?? '-'); ?></td>
                        </tr>
                    </table>
                </div>
            </div>

            <h5 class="mb-3">Daftar Barang</h5>
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead class="thead-light">
                        <tr>
                            <th width="50">No</th>
                            <th>Nama Barang</th>
                            <th width="150" class="text-right">Jumlah</th>
                            <th width="100">Satuan</th>
                            <th>Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $suratJalan->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($item->barang); ?></td>
                            <td class="text-right"><?php echo e($item->jumlah + 0); ?></td> 
                            <td><?php echo e($item->satuan); ?></td>
                            <td><?php echo e($item->keterangan); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
            </div>

            <!--[if BLOCK]><![endif]--><?php if($suratJalan->keterangan): ?>
            <div class="mt-4">
                <h6>Keterangan Tambahan:</h6>
                <div class="p-3 bg-light rounded border">
                    <?php echo e($suratJalan->keterangan); ?>

                </div>
            </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php if($suratJalan->bukti_suratjalan): ?>
            <div class="mt-4">
                <h6>Bukti Surat Jalan:</h6>
                <a href="<?php echo e(asset('storage/' . $suratJalan->bukti_suratjalan)); ?>" target="_blank">
                    <img src="<?php echo e(asset('storage/' . $suratJalan->bukti_suratjalan)); ?>" alt="Bukti Surat Jalan" class="img-fluid rounded shadow-sm border" style="max-height: 250px;">
                </a>
            </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        </div>
    </div>
</div>
<?php /**PATH /media/cerita_oca/New Volume1/Project Pribadi/erpkonveksi/resources/views/livewire/surat-jalan/detail.blade.php ENDPATH**/ ?>