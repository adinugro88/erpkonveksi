<?php $__env->startSection('Judul','Surat Jalan'); ?>
<?php $__env->startSection('action', $sj_id ? 'Edit Surat Jalan' : 'Buat Surat Jalan Baru'); ?>

<?php $__env->startSection('style'); ?>
<style>
    .ts-wrapper .ts-control {
        padding: 0 !important;
        border: 0 !important;
    }
</style>
<?php $__env->stopSection(); ?>

<div class="container pb-5">
    <div class="card">
        <div class="card-header bg-<?php echo e($jenis == 'keluar' ? 'warning' : 'success'); ?> text-white">
            <h5 class="mb-0">Form Surat Jalan (<?php echo e(strtoupper($jenis)); ?>)</h5>
        </div>
        <div class="card-body">
            <form wire:submit.prevent="save">
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Jenis <span class="text-danger">*</span></label>
                            <div wire:ignore>
                                <select id="selectjenis" class="form-control" wire:model.live="jenis" <?php if($sj_id): ?> disabled <?php endif; ?>>
                                    <option value="keluar">KELUAR (PENGIRIMAN)</option>
                                    <option value="masuk">MASUK (Barang Masuk)</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Kode Surat Jalan <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" wire:model="kode_sj" readonly>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['kode_sj'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Tanggal <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" wire:model="tanggal">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group mb-3">
                            <label>Pekerjaan / Job <span class="text-danger">*</span></label>
                            <div wire:ignore>
                                <select id="selectjob" class="form-control" wire:model.live="job_cust_id">
                                    <option value="">-- Pilih Job --</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $jobsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($job->id); ?>"><?php echo e($job->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                            </div>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['job_cust_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="form-group">
                            <label>Customer</label>
                            <input type="text" class="form-control bg-light" wire:model="customer" readonly placeholder="Nama Customer (Otomatis)">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Keterangan Umum</label>
                            <textarea class="form-control" wire:model="keterangan" rows="1"></textarea>
                        </div>
                    </div>
                </div>

                <hr>
                <h6>Bukti Surat Jalan</h6>
                <div class="row">
                    <div class="col-12">
                        <div class="text-center bg-light rounded position-relative" style="border: 2px dashed #ced4da; min-height: 200px; display: flex; align-items: center; justify-content: center;">
                            <div wire:loading wire:target="bukti_suratjalan" class="p-4">
                                <i class="fas fa-spinner fa-spin fa-2x text-muted"></i>
                                <span class="d-block text-muted small mt-2">Uploading...</span>
                            </div>
                            <div wire:loading.remove wire:target="bukti_suratjalan" class="w-100 p-3">
                                <!--[if BLOCK]><![endif]--><?php if($bukti_suratjalan): ?>
                                    <img src="<?php echo e($bukti_suratjalan->temporaryUrl()); ?>" class="img-fluid rounded shadow-sm" style="max-height: 220px;">
                                    <div class="d-flex justify-content-center align-items-stretch mt-3 mb-1">
                                        <label for="buktiSuratJalanInput" class="btn btn-lg btn-outline-secondary px-3 mr-2 d-flex align-items-center justify-content-center mb-0" style="cursor:pointer; white-space: nowrap;">
                                            <i class="fas fa-camera mr-1"></i> Ganti Photo
                                        </label>
                                        <button type="button" class="btn btn-lg btn-outline-danger px-3 d-flex align-items-center justify-content-center mb-0" style="white-space: nowrap;" wire:click="removeBukti"
                                            onclick="if(!confirm('Hapus photo ini?')) { return false; }">
                                            <i class="fas fa-trash mr-1"></i> Hapus Photo
                                        </button>
                                    </div>
                                <?php elseif($buktiSuratjalanUrl): ?>
                                    <img src="<?php echo e($buktiSuratjalanUrl); ?>" class="img-fluid rounded shadow-sm" style="max-height: 220px;">
                                    <div class="d-flex justify-content-center align-items-stretch mt-3 mb-1">
                                        <label for="buktiSuratJalanInput" class="btn btn-lg btn-outline-secondary px-3 mr-2 d-flex align-items-center justify-content-center mb-0" style="cursor:pointer; white-space: nowrap;">
                                            <i class="fas fa-camera mr-1"></i> Ganti Photo
                                        </label>
                                        <button type="button" class="btn btn-lg btn-outline-danger px-3 d-flex align-items-center justify-content-center mb-0" style="white-space: nowrap;" wire:click="removeBukti"
                                            onclick="if(!confirm('Hapus photo ini?')) { return false; }">
                                            <i class="fas fa-trash mr-1"></i> Hapus Photo
                                        </button>
                                    </div>
                                <?php else: ?>
                                    <label for="buktiSuratJalanInput" class="mb-0 d-block w-100" style="cursor:pointer; padding: 45px 0;">
                                        <i class="fas fa-cloud-upload-alt fa-3x text-muted"></i>
                                        <span class="d-block text-muted font-weight-bold mt-2">Upload Photo</span>
                                        <span class="d-block text-muted small">Klik untuk memilih gambar (Maks. 5MB)</span>
                                    </label>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                        <input type="file" wire:model="bukti_suratjalan" id="buktiSuratJalanInput" accept="image/*" class="d-none">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['bukti_suratjalan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>

                <hr>
                <h6>Logistik & Pengiriman</h6>
                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>Pengirim</label>
                            <input type="text" class="form-control" wire:model="pengirim" placeholder="Nama Pengirim">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>Penerima</label>
                            <input type="text" class="form-control" wire:model="penerima" placeholder="Nama Penerima">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>Sopir / Driver</label>
                            <input type="text" class="form-control" wire:model="sopir" placeholder="Nama Sopir">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>No. Kendaraan</label>
                            <input type="text" class="form-control" wire:model="no_kendaraan" placeholder="B 1234 ABC">
                        </div>
                    </div>
                </div>

                <hr>
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h6 class="mb-0">Daftar Barang</h6>
                </div>

                <div class="mb-3">
                    <!-- Desktop Header -->
                    <div class="d-none d-md-flex row font-weight-bold bg-light py-2 px-2 border rounded-top">
                        <div class="col-md-4">Nama Barang <span class="text-danger">*</span></div>
                        <div class="col-md-2">Jumlah <span class="text-danger">*</span></div>
                        <div class="col-md-2">Satuan</div>
                        <div class="col-md-3">Keterangan</div>
                        <div class="col-md-1"></div>
                    </div>

                    <!-- Items List -->
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row border-bottom py-3 px-2 <?php echo e($loop->even ? 'bg-light' : ''); ?> align-items-center">
                        <!-- Nama Barang -->
                        <div class="col-12 col-md-4 mb-2 mb-md-0">
                            <label class="d-md-none font-weight-bold">Nama Barang <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" wire:model="items.<?php echo e($index); ?>.barang" placeholder="Nama Barang">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['items.'.$index.'.barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small d-block"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <!-- Jumlah -->
                        <div class="col-12 col-md-2 mb-2 mb-md-0">
                            <label class="d-md-none font-weight-bold">Jumlah <span class="text-danger">*</span></label>
                            <input type="number" step="0.01" class="form-control" wire:model="items.<?php echo e($index); ?>.jumlah" placeholder="0">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['items.'.$index.'.jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small d-block"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <!-- Satuan -->
                        <div class="col-12 col-md-2 mb-2 mb-md-0">
                            <label class="d-md-none font-weight-bold">Satuan</label>
                            <input type="text" class="form-control" wire:model="items.<?php echo e($index); ?>.satuan" placeholder="Pcs/Kg">
                        </div>

                        <!-- Keterangan -->
                        <div class="col-12 col-md-3 mb-2 mb-md-0">
                            <label class="d-md-none font-weight-bold">Keterangan</label>
                            <input type="text" class="form-control" wire:model="items.<?php echo e($index); ?>.keterangan" placeholder="Catatan">
                        </div>

                        <!-- Action -->
                        <div class="col-12 col-md-1 text-center">
                            <!--[if BLOCK]><![endif]--><?php if(count($items) > 1): ?>
                            <button type="button" class="btn btn-block btn-danger btn-lg d-md-none mt-2" wire:click="removeItem(<?php echo e($index); ?>)">
                                <i class="fas fa-trash"></i> Hapus Item
                            </button>
                            <button type="button" class="btn btn-danger btn-lg d-none d-md-block mx-auto" wire:click="removeItem(<?php echo e($index); ?>)">
                                <i class="fas fa-times"></i>
                            </button>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
                
                <div class="text-right mb-4">
                    <button type="button" class="btn btn-lg btn-info" wire:click="addItem">
                        <i class="fas fa-plus"></i> Tambah Baris
                    </button>
                </div>

                <div class="mt-4 text-right">
                    <a href="<?php echo e(route('surat-jalan.index')); ?>" class="btn btn-secondary">Batal</a>
                    <button type="submit" class="btn btn-primary px-5">
                        <i class="fas fa-save"></i> Simpan Surat Jalan ini
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('livewire:initialized', () => {
        const initTomSelect = (id, modelName) => {
            const el = document.getElementById(id.replace('#',''));
            if(!el) return;
            if(el.closest('.ts-wrapper')) return;

            new TomSelect(id, {
                onInitialize: function() {
                    this.on('change', function(value) {
                       window.Livewire.find('<?php echo e($_instance->getId()); ?>').set(modelName, value);
                    });
                }
            });
        };

        initTomSelect('#selectjob', 'job_cust_id');
        initTomSelect('#selectjenis', 'jenis');
    });
</script>
<?php $__env->stopSection(); ?>
<?php /**PATH /media/cerita_oca/New Volume1/Project Pribadi/erpkonveksi/resources/views/livewire/surat-jalan/form.blade.php ENDPATH**/ ?>