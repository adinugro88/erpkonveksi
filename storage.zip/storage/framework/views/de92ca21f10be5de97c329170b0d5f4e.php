<?php $__env->startSection('Judul','Surat Jalan'); ?>
<?php $__env->startSection('action','Daftar Surat Jalan'); ?>

<div class="container">
    <div class="card p-3">
        <div class="row mb-3">
            <div class="col-md-4">
                <input type="text" class="form-control" placeholder="Cari Kode SJ atau Job..." wire:model.live="search">
            </div>
            <div class="col-md-3 my-3">
                <select class="form-control" wire:model.live="filterJenis">
                    <option value="">-- Semua Jenis --</option>
                    <option value="keluar">SJ KELUAR (OUT)</option>
                    <option value="masuk">SJ MASUK (IN)</option>
                </select>
            </div>
            <div class="col-md-5 text-right">
                <a href="<?php echo e(route('surat-jalan.form')); ?>" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Buat Surat Jalan Baru
                </a>
            </div>
        </div>

        <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead class="thead-light">
                    <tr>
                        <th width="50">No</th>
                        <th>Kode SJ</th>
                        <th>Tanggal</th>
                        <th>Job / Customer</th>
                        <th>Jenis</th>
                        <th>Item(s)</th>
                        <th>Driver</th>
                        <th width="150">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = ($suratJalans->currentPage() - 1) * $suratJalans->perPage(); ?>
                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $suratJalans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e(++$i); ?></td>
                            <td><code><?php echo e($sj->kode_sj); ?></code></td>
                            <td><?php echo e(\Carbon\Carbon::parse($sj->tanggal)->format('d/m/Y')); ?></td>
                            <td>
                                <strong><?php echo e($sj->jobCust->nama); ?></strong><br>
                                <small class="text-muted"><?php echo e($sj->jobCust->Customer->nama ?? '-'); ?></small>
                            </td>
                            <td>
                                <span class="badge badge-<?php echo e($sj->jenis == 'keluar' ? 'warning' : 'success'); ?>">
                                    <?php echo e(strtoupper($sj->jenis)); ?>

                                </span>
                            </td>
                            <td>
                                <span class="badge badge-info"><?php echo e($sj->details_count); ?> Item</span>
                            </td>
                            <td><?php echo e($sj->sopir ?: '-'); ?></td>
                            <td>
                                <div class="d-flex flex-wrap" style="gap: 5px;">
                                    <a href="<?php echo e(route('surat-jalan.detail', $sj->id)); ?>" class="btn btn-lg btn-info">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('surat-jalan.form', $sj->id)); ?>" class="btn btn-lg btn-warning">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <button onclick="confirm('Yakin ingin menghapus?') || event.stopImmediatePropagation()" 
                                            wire:click="delete(<?php echo e($sj->id); ?>)" class="btn btn-lg btn-danger">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center">Data tidak ditemukan.</td>
                        </tr>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>
        </div>

        <div class="mt-3">
            <?php echo e($suratJalans->links()); ?>

        </div>
    </div>
</div>
<?php /**PATH /media/cerita_oca/New Volume1/Project Pribadi/erpkonveksi/resources/views/livewire/surat-jalan/index.blade.php ENDPATH**/ ?>